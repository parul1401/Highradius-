package back_servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDBConnections {

	public static Connection createConnect() {
		// TODO Auto-generated method stub
		Connection con = null;
		String url = "jdbc:mysql://localhost:4040/grey_goose?zeroDateTimeBehavior=convertToNull";
		String uname = "root";
		String pass = "P@r3014ul";

		try {
			try {

				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			con = DriverManager.getConnection(url, uname, pass);
			System.out.println("Post establishing a DB connection - " + con);

		} catch (SQLException e) {
			System.out.println("Error Found");
			e.printStackTrace();
		}
		return con;

	}

}
