module HRC_Backend {
	exports back_servlets;
}