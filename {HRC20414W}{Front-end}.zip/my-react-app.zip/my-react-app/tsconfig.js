{
    "compilerOptions": {
      "target": "es6",
      "removeComments": false,
      "jsx": "react",
      "moduleResolution": "node"
    },
    "include": [
      "src"
    ]
  }