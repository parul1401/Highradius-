import "./App.css";
import NavBar from "./Components/NavBar";
import Footer from "./Components/Footer";
import IndexBody from "./Components/IndexBody";
import DataTable from "./Components/DataTable";
// import EnhancedTable from "./Components/DemoTable";
// import MyGrid from "./Components/MyGrid";

const App = () => {
  return (
    <>
      <div className="app">
        <NavBar />
        <IndexBody />
        <DataTable />
        <Footer />
      </div>
    </>
  );
}

export default App;
