import React from "react";
import Button from "@material-ui/core/Button";
import { makeStyles } from "@material-ui/core/styles";
import AdvanceSearch from "./Modals/AdvanceSearch";
import ButtonGroup from "@material-ui/core/ButtonGroup";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRefresh } from "@fortawesome/free-solid-svg-icons";
import AddInvoice from "./Modals/add";
import EditInvoice from "./Modals/Edit";
import DeleteInvoice from "./Modals/Delete";

const useStyles = makeStyles((theme) => ({
  root: {
    textAlign: "center",
    marginTop: "50px",
  },
  btns: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  btnsize: {
    width: "150px",
    height: "34px",
  },
}));

function IndexBody() {
  const refreshPage = () => {
    window.location.reload();
  };

  const classes = useStyles();
  return (
    <div className="indexBody">
      <div className={classes.btns}>
        <ButtonGroup
          variant="outlined"
          aria-label="outlined button group"
          color="primary"
          style={{ float: "left", marginLeft: "20px" }}
        >
          <Button
            className="active"
            style={{ color: "white", width: "200px", height: "34px" }}
          >
            PREDICT
          </Button>
          <Button style={{ color: "white", width: "200px", height: "34px" }}>
            ANALYTICS VIEW
          </Button>
          <Button style={{ color: "white", width: "200px", height: "34px" }}>
            {/* <AdvanceSearch /> */}
          </Button>
        </ButtonGroup>
      </div>

      <div className={classes.btns} style={{ float: "left" }}>
        <Button
          onClick={refreshPage}
          style={{ height: "34px" }}
          variant="outlined"
          color="primary"
        >
          <FontAwesomeIcon icon={faRefresh}></FontAwesomeIcon>
        </Button>
      </div>

      <div className={classes.btns} style={{ float: "left" }}>
        <input
          type="text"
          placeholder="search customer id"
          style={{ height: "29px", borderRadius: "8px", marginRight: "70px" }}
        ></input>
      </div>
      <div style={{ positions: "fixed" }}>
        <div style={{ float: "left", marginTop: "7px" }}>
          <AddInvoice />
        </div>
        <div className="" style={{ float: "left", marginTop: "7px" }}>
          <EditInvoice
          // invoice_currency={ic}
          // customer_payment_terms={cpt}
          // changeHandler={changeHandler}
          />
        </div>
        <div className="" style={{ float: "left", marginTop: "7px" }}>
          <DeleteInvoice />
        </div>
      </div>
    </div>
  );
}

export default IndexBody;
